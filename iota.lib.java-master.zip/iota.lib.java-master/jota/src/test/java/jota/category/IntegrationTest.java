package jota.category;

public interface IntegrationTest {
}
