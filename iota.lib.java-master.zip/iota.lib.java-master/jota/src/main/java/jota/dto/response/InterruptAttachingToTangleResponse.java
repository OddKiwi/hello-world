package jota.dto.response;

/**
 * Response of {@link jota.dto.request.IotaCommandRequest}.
 **/
public class InterruptAttachingToTangleResponse extends AbstractResponse {
    // empty response
}
