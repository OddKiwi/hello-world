package jota.dto.response;

/**
 * Response of {@link jota.dto.request.IotaBroadcastTransactionRequest}.
 **/
public class BroadcastTransactionsResponse extends AbstractResponse {
    // empty response
}
